#pragma once

#include <raylib.h>
#include <stdlib.h>
#include <time.h>
#include "ball.h"
#include "orificios.h"
#include "estados.h"
#include <string.h>
#include <stdio.h> 

void llenaopcnivel(int nivel, int opc[], int &nops);
void sacapromedio (int opcs [], int nopc, int promedio);
void llenaopcnivel(int nivel, int opc[], int &nops)
{
    switch (nivel)
    {
    case 1:

        opc[0] = 1;
        opc[1] = 10;
        opc[2] = 100;
        opc[3] = 1000;
        nops = 4;
        break;

    case 2:
        opc[0] = 1;
        opc[1] = 10;
        opc[2] = 100;
        opc[3] = 1000;
        opc[4] = opc[2];
        nops = 5;

        break;

    case 3:
        opc[0] = 1;
        opc[1] = 10;
        opc[2] = 100;
        opc[3] = 1000;
        opc[4] = opc[0] * -1;
        opc[5] = opc[1] * -1;
        opc[6] = opc[2] * -1;
        opc[7] = opc[3] * -1;

        nops = 8;

        break;

    case 4:
        nops = 8;

        opc[0] = 1 + rand() % 9;
        opc[1] = 10 + rand() % 60;
        opc[2] = 61 + rand() % 100;
        opc[3] = 101 + rand() % 1000;
        opc[4] = opc[0] * -1;
        opc[5] = opc[1] * -1;
        opc[6] = opc[2] * -1;
        opc[7] = opc[3] * -1;
        opc[8] = opc[0];
        opc[9] = opc[1];
        opc[10] = opc[2];
        opc[11] = opc[3];

        nops = 12;

        break;

    case 5:

        opc[0] = 1 + rand() % 9;
        opc[1] = 10 + rand() % 60;
        opc[2] = 61 + rand() % 100;
        opc[3] = 101 + rand() % 1000;
        opc[4] = opc[0] * -1;
        opc[5] = opc[1] * -1;
        opc[6] = opc[2] * -1;
        opc[7] = opc[3] * -1;

        nops = 8;

        break;

    case 6:
        opc[0] = 1 + rand() % 9;
        opc[1] = 10 + rand() % 60;
        opc[2] = 61 + rand() % 100;
        opc[3] = 101 + rand() % 1000;
        opc[4] = (1 + rand() % 9) * -1;
        opc[6] = (61 + rand() % 100) * -1;
        opc[7] = (101 + rand() % 1000) * -1;
        opc[8] = opc[0] * -1;
        opc[9] = opc[1] * -1;
        opc[10] = opc[2] * -1;
        opc[11] = opc[3] * -1;

        nops = 12;

        break;

    default:

        opc[0] = 1;
        nops = 1;
    }
}
void sacapromedio (int opcs [], int nopc, int promedio)
{
    int suma = 0;
    for (int i = 0; i < nopc; i++)
    {
        suma += opcs[i];
    }

    promedio = suma / nopc;
                

}